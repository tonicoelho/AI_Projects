
# -u unbuffered

python3 -u environment.py
