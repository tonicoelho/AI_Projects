"""
ad_agent.py
Advertisement Selection Engine that employs a Decision Network (Bayesian Network)
to Maximize Expected Utility (MEU), compute Value of Perfect Information (VPI),
and infer most likely consumer profiles based on partial evidence.
"""
    
import itertools
import pandas as pd
from pgmpy.models import BayesianNetwork
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.inference import VariableElimination
from pgmpy.inference.CausalInference import CausalInference

class AdEngine:
    def __init__(self, data: pd.DataFrame, structure: list[tuple[str, str]],
                 dec_vars: list[str], util_map: dict[str, dict[int, int]]):
        """
        Initialize the Bayesian Decision Network.
        """
        self.dec_vars = set(dec_vars)
        self.util_map = util_map
        self.structure = [(p, c) for p, c in structure if p in data.columns and c in data.columns]
        self.model = BayesianNetwork(self.structure)
        self.domains = {col: sorted(data[col].unique()) for col in data.columns}
        self.model.fit(data, estimator=MaximumLikelihoodEstimator, state_names=self.domains)
        self.ve_infer = VariableElimination(self.model)
        self.causal_infer = CausalInference(self.model)
        self.chance_vars = set(data.columns) - self.dec_vars

    def meu(self, evidence: dict[str, int]) -> tuple[dict[str, int], float]:
        """
        Compute Maximum Expected Utility (MEU) using the do-operator.
        """
        best_utility = float('-inf')
        best_assignment = {}
        all_combos = itertools.product(*[self.domains[d] for d in self.dec_vars])

        for combo in all_combos:
            dec_assignment = dict(zip(self.dec_vars, combo))
            total_utility = 0.0
            for util_var, payoff in self.util_map.items():
                qres = self.causal_infer.query(
                    variables=[util_var],
                    do=dec_assignment,
                    evidence=evidence,
                    inference_algo='ve',
                    show_progress=False
                )
                probs = qres.values
                states = self.domains[util_var]
                for i in range(len(states)):
                    total_utility += probs[i] * payoff.get(states[i], 0)
            if total_utility > best_utility:
                best_utility = total_utility
                best_assignment = dec_assignment
        return best_assignment, best_utility

    def vpi(self, potential_evidence: str, observed_evidence: dict[str, int]) -> float:
        """
        Compute Value of Perfect Information (VPI).
        """
        _, baseline_meu = self.meu(observed_evidence)
        qres = self.ve_infer.query(
            variables=[potential_evidence],
            evidence=observed_evidence,
            show_progress=False
        )
        probs = qres.values
        states = self.domains[potential_evidence]
        weighted_meu = 0.0
        for i in range(len(states)):
            new_evidence = observed_evidence.copy()
            new_evidence[potential_evidence] = states[i]
            _, new_meu = self.meu(new_evidence)
            weighted_meu += probs[i] * new_meu
        return max(0.0, weighted_meu - baseline_meu)

    def most_likely_consumer(self, evidence: dict[str, int]) -> dict[str, int]:
        """
        Predict the most likely consumer profile (MAP assignment).
        """
        missing_vars = [var for var in self.chance_vars if var not in evidence]
        ml = self.ve_infer.map_query(
            variables=missing_vars,
            evidence=evidence,
            show_progress=False
        ) if missing_vars else {}
        result = evidence.copy()
        result.update(ml)
        return {k: int(v) for k, v in result.items()}